const ApiUrls = {
    photos: 'photos'
};

export default ApiUrls;